from UnchainedLabs import Lunatic

lunatic_1 = Lunatic(file_path='Data/Instrument Sample.xlsx')
print(lunatic_1.getInfo())
print(lunatic_1.getPlateInfo())